import token from "./hooks/token";
import walls from "./hooks/walls";

export default function() 
{
    token();
    walls();
}